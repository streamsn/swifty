import { useState, useEffect } from "react";

// Types and Mock Data
interface ProductIdea {
  id: number;
  type: string;
  title: string;
  price: string;
  estimatedEffort: string;
  outline: string[];
  salesHook: string;
}

const MOCK_IDEAS: ProductIdea[] = [
  {
    id: 1,
    type: "Template / Toolkit",
    title: "Faceless Creator Content OS",
    price: "$27",
    estimatedEffort: "3 hours",
    salesHook: "How I plan 30 days of viral content in 2 hours without showing my face.",
    outline: [
      "Content Matrix (Notion Template)",
      "50 Hook Formulas for short-form video",
      "Schedules & tracking automated dashboard",
      "Analytics tracker"
    ]
  },
  {
    id: 2,
    type: "Mini-Guide / Ebook",
    title: "The $1K Micro-Sponsorship Guide",
    price: "$19",
    estimatedEffort: "4 hours",
    salesHook: "Get brands to pay you $500/post even if you only have 2,000 followers.",
    outline: [
      "Outreach script templates",
      "Pricing calculator",
      "Media kit layout",
      "Negotiation cheatsheet"
    ]
  },
  {
    id: 3,
    type: "Paid Community",
    title: "Storytelling Mastermind Group",
    price: "$49/mo",
    estimatedEffort: "Ongoing (1 hr/week)",
    salesHook: "Connect with 50+ aesthetic creators sharing secret trends and feedback.",
    outline: [
      "Private Discord channel",
      "Weekly trends teardown",
      "Critique calls every Thursday",
      "Co-working sessions"
    ]
  }
];

export default function App() {
  const [step, setStep] = useState<"landing" | "analyzing" | "results" | "builder">("landing");
  const [handle, setHandle] = useState("");
  const [platform, setPlatform] = useState("tiktok");
  const [selectedProduct, setSelectedProduct] = useState<ProductIdea | null>(null);
  const [progress, setProgress] = useState(0);

  // Analyze loading effect
  useEffect(() => {
    if (step === "analyzing") {
      setProgress(0);
      const timer = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 100) {
            clearInterval(timer);
            setStep("results");
            return 100;
          }
          return prev + 5;
        });
      }, 150);
      return () => clearInterval(timer);
    }
  }, [step]);

  const handleAnalyze = (e: React.FormEvent) => {
    e.preventDefault();
    if (handle.trim() === "") return;
    setStep("analyzing");
  };

  const selectProduct = (prod: ProductIdea) => {
    setSelectedProduct(prod);
    setStep("builder");
  };

  return (
    <div className="min-h-screen bg-white text-neutral-900 font-sans tracking-tight">
      {/* Navbar */}
      <nav className="border-b border-neutral-100 sticky top-0 bg-white/80 backdrop-blur-md z-50">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-2 font-bold text-xl tracking-tighter">
            <span className="bg-neutral-900 text-white px-2 py-1 rounded">L</span>
            <span>LaunchPartner</span>
          </div>
          <div className="flex items-center space-x-4 text-sm font-medium">
            {step === "results" || step === "builder" ? (
              <button
                onClick={() => setStep("landing")}
                className="text-neutral-500 hover:text-neutral-900 transition-colors"
              >
                Reset
              </button>
            ) : null}
            <span className="text-neutral-400">v1.0 (MVP)</span>
          </div>
        </div>
      </nav>

      <main className="max-w-5xl mx-auto px-4 py-12">
        {/* VIEW 1: LANDING & HANDLE ENTRY */}
        {step === "landing" && (
          <div className="max-w-2xl mx-auto text-center py-12">
            <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight mb-4">
              Stop leaving money on the table.
            </h1>
            <p className="text-xl text-neutral-500 mb-12">
              We analyze your content and tell you exactly what digital product your followers will buy today.
            </p>

            <form onSubmit={handleAnalyze} className="space-y-6 bg-neutral-50 p-8 rounded-2xl border border-neutral-100">
              <div className="flex flex-col sm:flex-row gap-3">
                <div className="flex-1 flex border border-neutral-200 rounded-lg bg-white overflow-hidden focus-within:ring-2 focus-within:ring-neutral-900 focus-within:border-transparent transition">
                  <select 
                    value={platform} 
                    onChange={(e) => setPlatform(e.target.value)}
                    className="bg-neutral-100 px-3 text-sm font-medium border-r border-neutral-200 outline-none"
                  >
                    <option value="tiktok">TikTok</option>
                    <option value="instagram">Instagram</option>
                    <option value="youtube">YouTube</option>
                    <option value="x">X / Twitter</option>
                  </select>
                  <span className="flex items-center pl-3 text-neutral-400">@</span>
                  <input
                    type="text"
                    placeholder="yourhandle"
                    value={handle}
                    onChange={(e) => setHandle(e.target.value)}
                    className="flex-1 px-2 py-3 outline-none"
                    required
                  />
                </div>
                <button
                  type="submit"
                  className="bg-neutral-900 hover:bg-neutral-800 text-white font-medium py-3 px-6 rounded-lg transition shadow-sm"
                >
                  Analyze Profile
                </button>
              </div>
              <p className="text-xs text-neutral-400 flex items-center justify-center gap-1">
                ⚡ Takes under 30 seconds. No password required.
              </p>
            </form>

            <div className="mt-16 grid grid-cols-1 sm:grid-cols-3 gap-6 text-left border-t border-neutral-100 pt-12">
              <div>
                <h3 className="font-bold text-lg mb-2">Analyze Content</h3>
                <p className="text-sm text-neutral-500">We crawl your top posts to see what your audience asks about.</p>
              </div>
              <div>
                <h3 className="font-bold text-lg mb-2">Generate Offers</h3>
                <p className="text-sm text-neutral-500">AI finds the overlaps between your skills and what buyers want.</p>
              </div>
              <div>
                <h3 className="font-bold text-lg mb-2">Launch in Hours</h3>
                <p className="text-sm text-neutral-500">Get pre-written templates and sales pages to start selling immediately.</p>
              </div>
            </div>
          </div>
        )}

        {/* VIEW 2: ANALYZING (LOADING) */}
        {step === "analyzing" && (
          <div className="max-w-md mx-auto text-center py-20 flex flex-col items-center">
            <div className="w-16 h-16 border-4 border-neutral-100 border-t-neutral-900 rounded-full animate-spin mb-6"></div>
            <h2 className="text-2xl font-bold mb-2">Analyzing @{handle}</h2>
            <p className="text-neutral-500 mb-8">Reading engagement patterns, themes, and comments...</p>

            <div className="w-full bg-neutral-100 h-2 rounded-full overflow-hidden">
              <div 
                className="h-full bg-neutral-900 transition-all duration-150" 
                style={{ width: `${progress}%` }}
              ></div>
            </div>
            <div className="mt-4 text-xs font-mono text-neutral-400">
              {progress < 30 && "Fetching top 20 posts..."}
              {progress >= 30 && progress < 70 && "Running semantic analysis on 500+ comments..."}
              {progress >= 70 && progress < 100 && "Matching findings with profitable monetization models..."}
              {progress === 100 && "Finalizing results..."}
            </div>
          </div>
        )}

        {/* VIEW 3: RESULTS / IDEAS */}
        {step === "results" && (
          <div className="space-y-8 py-6">
            <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <span className="text-xs font-semibold uppercase tracking-wider text-neutral-400">Analysis Complete for @{handle}</span>
                <h1 className="text-3xl font-bold mt-1">Found 3 High-Potential Products</h1>
              </div>
              <button 
                onClick={() => setStep("landing")}
                className="text-sm border border-neutral-200 hover:border-neutral-900 rounded-lg px-4 py-2 font-medium transition"
              >
                Scan New Account
              </button>
            </header>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {MOCK_IDEAS.map((idea) => (
                <div key={idea.id} className="border border-neutral-200 rounded-xl p-6 flex flex-col justify-between hover:border-neutral-900 transition-colors shadow-sm bg-white">
                  <div>
                    <span className="inline-block bg-neutral-100 text-neutral-800 text-xs font-semibold px-2.5 py-1 rounded-full mb-4">
                      {idea.type}
                    </span>
                    <h3 className="text-xl font-bold mb-2">{idea.title}</h3>
                    <p className="text-sm text-neutral-600 mb-4 font-medium italic">"{idea.salesHook}"</p>
                    
                    <div className="space-y-2 mb-6">
                      <div className="flex justify-between text-sm">
                        <span className="text-neutral-500">MSRP Pricing</span>
                        <span className="font-semibold text-neutral-900">{idea.price}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-neutral-500">Build Time</span>
                        <span className="font-semibold text-neutral-900">{idea.estimatedEffort}</span>
                      </div>
                    </div>
                  </div>

                  <button 
                    onClick={() => selectProduct(idea)}
                    className="w-full bg-neutral-900 hover:bg-neutral-800 text-white py-2.5 rounded-lg text-sm font-medium transition flex items-center justify-center gap-1"
                  >
                    Build & Launch 
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M13 7l5 5m0 0l-5 5m5-5H6" />
                    </svg>
                  </button>
                </div>
              ))}
            </div>

            <div className="bg-neutral-50 border border-neutral-100 rounded-xl p-6 flex flex-col sm:flex-row items-center justify-between gap-4 mt-12">
              <div>
                <h4 className="font-bold">Not seeing exactly what you want?</h4>
                <p className="text-sm text-neutral-600">Upgrade to Pro to prompt our AI with custom constraints or target niches.</p>
              </div>
              <button className="bg-neutral-900 text-white text-sm font-medium px-4 py-2.5 rounded-lg whitespace-nowrap">
                Unlock Custom Generation ($29/mo)
              </button>
            </div>
          </div>
        )}

        {/* VIEW 4: BUILDER / ONE-PRODUCT DEEP DIVE */}
        {step === "builder" && selectedProduct && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 py-6">
            {/* Left Col: Setup */}
            <div className="lg:col-span-2 space-y-6">
              <header className="mb-8">
                <button 
                  onClick={() => setStep("results")}
                  className="flex items-center text-sm text-neutral-500 hover:text-neutral-900 mb-4 transition"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2} className="mr-1">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M11 17l-5-5m0 0l5-5m-5 5h12" />
                  </svg>
                  Back to ideas
                </button>
                <span className="text-xs font-semibold text-neutral-400 uppercase tracking-wider">Product Builder MVP</span>
                <h2 className="text-3xl font-bold mt-1">{selectedProduct.title}</h2>
              </header>

              <div className="bg-white border border-neutral-200 rounded-xl p-6 shadow-sm">
                <h3 className="font-bold text-lg mb-4">Content Outline (AI Generated)</h3>
                <ul className="space-y-4">
                  {selectedProduct.outline.map((item, index) => (
                    <li key={index} className="flex items-start gap-3">
                      <span className="flex-shrink-0 h-6 w-6 rounded-full bg-neutral-900 text-white text-xs flex items-center justify-center font-bold">
                        {index + 1}
                      </span>
                      <div>
                        <p className="font-medium text-sm text-neutral-900">{item}</p>
                        <p className="text-xs text-neutral-500">Auto-generated prompt for production.</p>
                      </div>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-white border border-neutral-200 rounded-xl p-6 shadow-sm">
                <h3 className="font-bold text-lg mb-4">Marketing Hooks</h3>
                <div className="space-y-3">
                  <div className="p-3 bg-neutral-50 border border-neutral-100 rounded-lg text-sm">
                    <span className="font-semibold block mb-1">Video Hook 1:</span>
                    "Stop scrolling if you are a creator. Here is how I set up my workspace in 3 hours to monetize my audience automatically..."
                  </div>
                  <div className="p-3 bg-neutral-50 border border-neutral-100 rounded-lg text-sm">
                    <span className="font-semibold block mb-1">Video Hook 2:</span>
                    "I get asked all the time how I do it. Here is the exact template I used to start landing brand sponsorships..."
                  </div>
                </div>
              </div>
            </div>

            {/* Right Col: Landing Page Preview */}
            <div className="lg:col-span-1">
              <div className="sticky top-24 border border-neutral-200 rounded-xl overflow-hidden shadow-md bg-white">
                <div className="bg-neutral-900 text-white text-xs px-4 py-2 font-mono flex items-center justify-between">
                  <span>Preview: sales-page-live.link</span>
                  <div className="flex space-x-1.5">
                    <div className="w-2.5 h-2.5 bg-red-500 rounded-full"></div>
                    <div className="w-2.5 h-2.5 bg-yellow-500 rounded-full"></div>
                    <div className="w-2.5 h-2.5 bg-green-500 rounded-full"></div>
                  </div>
                </div>
                <div className="p-6 h-[400px] overflow-y-auto bg-neutral-50 scrollbar-thin">
                  <div className="text-center mb-6">
                    <span className="text-xs text-neutral-400 font-medium">Digital Download</span>
                    <h4 className="text-xl font-bold mt-1">{selectedProduct.title}</h4>
                    <p className="text-xs mt-2 text-neutral-600">By @{handle}</p>
                  </div>
                  <div className="border border-dashed border-neutral-300 rounded-lg h-32 flex items-center justify-center mb-6 bg-white">
                    <span className="text-xs text-neutral-400">Product Placeholder Image</span>
                  </div>
                  <p className="text-sm text-center italic font-medium mb-4 text-neutral-800">
                    "{selectedProduct.salesHook}"
                  </p>
                  <button className="w-full bg-neutral-900 text-white py-3 rounded-lg font-bold text-sm mb-4">
                    Buy Now for {selectedProduct.price}
                  </button>
                  <div className="border-t border-neutral-200 pt-4">
                    <h5 className="text-xs font-bold mb-2">What you get:</h5>
                    <ul className="text-xs text-neutral-600 space-y-1.5">
                      {selectedProduct.outline.slice(0, 2).map((li, i) => (
                        <li key={i} className="flex items-center gap-1.5">
                          <svg className="w-3.5 h-3.5 text-neutral-900" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                            <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                          </svg>
                          {li}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
                <div className="p-4 bg-white border-t border-neutral-200">
                  <button className="w-full bg-neutral-900 hover:bg-neutral-800 text-white py-2.5 rounded-lg text-sm font-medium transition flex items-center justify-center gap-1">
                    Connect Stripe & Launch 
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M13 7l5 5m0 0l-5 5m5-5H6" />
                    </svg>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
      
      <footer className="border-t border-neutral-100 py-12 bg-neutral-50 mt-12">
        <div className="max-w-5xl mx-auto px-4 text-center">
          <div className="flex items-center justify-center space-x-2 font-bold mb-4 tracking-tighter">
            <span className="bg-neutral-900 text-white px-2 py-1 rounded">L</span>
            <span>LaunchPartner</span>
          </div>
          <p className="text-sm text-neutral-400">The minimalist MVP for creator product design. No bloat, just speed and outcomes.</p>
        </div>
      </footer>
    </div>
  );
}